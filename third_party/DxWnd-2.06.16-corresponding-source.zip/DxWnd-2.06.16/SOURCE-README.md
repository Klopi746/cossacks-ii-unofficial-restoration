# DxWnd 2.06.16 corresponding source collection

This collection accompanies the unmodified official DxWnd 2.06.16 host/hook,
Disasm.dll and MinHook.x86.dll distributed with Unofficial Restoration.
It is assembled from the matching official upstream v2_06_16_src.rar archive:
https://sourceforge.net/projects/dxwnd/files/Sources/v2_06_16_src.rar/download
Original archive SHA-256: 8F4BC9A324660B240E5F6747B4A84532D7B51FBDD60F52AE1F07D6FAA247D1FD

Included: host, dll, Include, Disasm201, minhook-1.3.4, and the upstream-supplied
Detours/Detours-main.zip containing the full Microsoft Detours source / MIT
license. Original source bytes and copyright notices are preserved. No game
files are included. Precompiled objects, caches, IDE output and unrelated
optional helper programs were omitted; rebuild libraries from their sources.
A machine-readable inventory records every included source file hash.

DxWnd: GPL-3.0-or-later, SFB7 / GHO; license in COPYING-GPL-3.0.txt.
Disassembler: GPL-3.0-or-later, Oleh Yuschuk; source headers carry the terms.
MinHook / HDE: BSD 2-clause; minhook-1.3.4/LICENSE.txt includes both notices.
Detours: MIT; see the nested archive's LICENSE.md.
Other incorporated source notices remain in dll/ (Wine LGPL, stb_dxt BSD,
S3TC MIT and mciplayer ISC-like terms). No license to the game is granted.

Upstream native build projects target Visual C++ 2008 / Win32 and MFC, with
Windows / legacy DirectX SDK headers and import libraries. These Microsoft
system development components are not redistributed. They must be obtained
under Microsoft's terms. Build MinHook with its supplied VC9 project; place
the generated import/static library where the host/hook project expects it.
Unpack Detours-main.zip and build its X86 library from its src/Makefile with
MSVC. The upstream contributor documents /Zc:sizedDealloc- and
/D_NO_CRT_STDIO_INLINE for VS2008-compatible library linkage:
https://sourceforge.net/p/dxwnd/discussion/general/thread/911dc12203/?page=6
Use the supplied Disasm201/disasm.vs2008 project for the disassembler DLL,
then dll/dxwnd.vs2008 and host/dxwndhost.vs2008 for the hook and GUI.
The project file lists some obsolete unused resources; active .rc resources
and the actual sdl / sdl2 include subdirectories are present.

This is the source set supplied for this upstream version, with the above
packaging changes only. Native DxWnd / Disasm / MinHook binaries are not
rebuilt by the restoration setup build; they are kept at the checked hashes.
A bit-identical native rebuild has not been performed. This statement is not
an assertion that native runtime or every compiler combination was tested.

The supplied Detours-main.zip identifies upstream commit
ea6c4ae7f3f1b1772b8a7cda4199230b932f5a50 in its ZIP comment.
Full additional license texts / source notices are included under licenses/.

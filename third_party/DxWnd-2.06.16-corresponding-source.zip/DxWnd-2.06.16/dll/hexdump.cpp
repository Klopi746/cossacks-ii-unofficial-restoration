#define  _CRT_SECURE_NO_WARNINGS
#include <windows.h>
#include "stdio.h"
#include "string.h"

//#define MAX_HEXDUMP 512
#define MAX_HEXDUMP 256

char *hexdump(unsigned char *Buffer, int len)
{
	static char sHexBuffer[3*MAX_HEXDUMP+12];
	char *s;
	int iMaxI;
	if(!Buffer) return "(NULL)";
	s=sHexBuffer;
	iMaxI = len;
	if(iMaxI > MAX_HEXDUMP) iMaxI = MAX_HEXDUMP;
	for (int i=0; i<iMaxI; i++){
		__try {
			sprintf(s, "%02.2X,", Buffer[i]); 
			s += 3;
		}
		__except(EXCEPTION_EXECUTE_HANDLER) {
			strcpy(s, "<e>,");
			i = iMaxI;
			break;
		}
	}
	*(--s)=0; // eliminate last comma
	if(len > iMaxI) strcpy(s, ",...");
	return sHexBuffer;
}